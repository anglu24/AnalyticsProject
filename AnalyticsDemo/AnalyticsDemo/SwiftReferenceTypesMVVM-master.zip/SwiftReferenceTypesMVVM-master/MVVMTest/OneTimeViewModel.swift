//
//  OneTimeViewModel.swift
//  MVVMTest
//
//  Created by 劉柏賢 on 2016/2/14.
//  Copyright © 2016年 劉柏賢. All rights reserved.
//

import UIKit

class OneTimeViewModel: BaseViewModel {

    var titleText: String? = "This is a one time binding."
    
}
